<?php
	//mysql_connect("127.0.0.1","root","");
	//mysql_select_db("SRT-droid");
	//mysql_connect("mysql7.000webhost.com","a3393770_srt","a6srtdroid");
	//mysql_select_db("a3393770_srt");
	mysql_connect("localhost","srt","srt123srt");
	mysql_select_db("srt");
?>